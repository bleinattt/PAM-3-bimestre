import React,{useState} from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert ,Image} from 'react-native';

// criar seu componentes personalizado

function Home() {
  const [nome , setNome] = useState(" ");
  const [ImageSource , setImageSource] = useState({});
  function trocarImagem() {
   if (nome== "Ricardo") {
      setImageSource(require('../img/peak.jpg'))
   }
   if (nome === null) {
      setImageSource(require('../img/sem-imagem.jpg'))
   }

  }
  
  return (
    <>
       <Text>Nome</Text>
        <TextInput
           style={{borderColor :"black",height:40,width:200,borderWidth:1,borderRadius:10,padding:5}}
            placeholder=" Digite Nome"
            value={nome}
            onChangeText={(text)=>{setNome(text)}}              
        />
        <Image source={trocarImagem(nome)}/>
        <Text>Olá {nome} </Text>
    </>
   )
}
export default Home;

/// fazer um css incorporado